package by.training.zorich.action.validator;

public interface StringTetrahedronValidator {
	boolean isValid(String tetrahedronVertexesCoordinates);
}
