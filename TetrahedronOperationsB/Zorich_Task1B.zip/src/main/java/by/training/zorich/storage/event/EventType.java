package by.training.zorich.storage.event;

public enum EventType {
	ADD, UPDATE, REMOVE
}
