package by.training.zorich.action.parser;

public class CoordinatesTetrahedronParserExсeption extends Exception {

	private static final long serialVersionUID = -5467834052544406581L;

	public CoordinatesTetrahedronParserExсeption() {
		super();
	}

	public CoordinatesTetrahedronParserExсeption(String message) {
		super(message);
	}

	public CoordinatesTetrahedronParserExсeption(String message, Exception exeption) {
		super(message, exeption);
	}

	public CoordinatesTetrahedronParserExсeption(Exception exeption) {
		super(exeption);
	}
}
