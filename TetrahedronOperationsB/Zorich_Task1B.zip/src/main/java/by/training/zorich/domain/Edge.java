package by.training.zorich.domain;

public enum Edge {
	AB, AC, AD, BC, BD, CD;
}
