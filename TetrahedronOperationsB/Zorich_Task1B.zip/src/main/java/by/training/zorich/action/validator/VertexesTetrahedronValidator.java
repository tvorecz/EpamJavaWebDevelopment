package by.training.zorich.action.validator;

public interface VertexesTetrahedronValidator {
	boolean isValid(double[][] tetrahedronVertexesCoordinates);
}
